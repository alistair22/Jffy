package com.example.alistair.jiffy.Friday;

public class UserOrder {
    String name, phone, email, password;

    public UserOrder(String name, String phone, String email, String password) {
        this.name = name;
        this.phone = phone;
        this.email = email;
        this.password = password;
    }
}
